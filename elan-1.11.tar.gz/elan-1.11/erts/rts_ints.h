/*
   File: rts_ints.h
   Provides int engine

   CVS ID: "$Id: rts_ints.h,v 1.2 2004/12/18 13:24:51 marcs Exp $"
*/

#ifndef IncRtsInts
#define IncRtsInts

extern int rts_int_pow_int (int a, int b);
extern int rts_maxint ();

#endif /* IncRtsInts */

